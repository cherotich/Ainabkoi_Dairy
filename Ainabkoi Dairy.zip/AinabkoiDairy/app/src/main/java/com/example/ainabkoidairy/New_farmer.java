package com.example.ainabkoidairy;


import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;


/**
 * A simple {@link Fragment} subclass.
 */
public class New_farmer extends Fragment {


    public New_farmer() {
        // Required empty public constructor
    }

    EditText newfarmernametxt,newfarmeridnotxt,newfarmerphonenotxt;
    Button submitnewfarmerbtn;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_new_farmer, container, false);
         newfarmernametxt = (EditText) view.findViewById(R.id.new_farmer_name);
         newfarmeridnotxt = (EditText) view.findViewById(R.id.new_farmer_IDNO);
         submitnewfarmerbtn =(Button) view.findViewById(R.id.new_farmer_submit_btn);
         newfarmerphonenotxt = (EditText) view.findViewById(R.id.new_farmer_phoneno);



       
       submitnewfarmerbtn.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               
               CheckDetailsNewFarmer();
               
           }
       });
        
        
        return view;
    }

    private void CheckDetailsNewFarmer()
    {

        String addnewfarmername = newfarmernametxt.getText().toString();
        String addnewfarmerid = newfarmeridnotxt.getText().toString();
        String addnewfarmerphoneno = newfarmerphonenotxt.getText().toString();
        if(TextUtils.isEmpty(addnewfarmername)){
            newfarmernametxt.requestFocus();
        }
        else if(TextUtils.isEmpty(addnewfarmerid)){
            newfarmeridnotxt.requestFocus();
        }
        else if(TextUtils.isEmpty(addnewfarmerphoneno))
        {
            newfarmerphonenotxt.requestFocus();
        }
        else {
         Addnewfarmer(addnewfarmername,addnewfarmerid,addnewfarmerphoneno);
        }

    }

    private void Addnewfarmer(final String addnewfarmername, final String addnewfarmerid, final String addnewfarmerphoneno)
    {
        final DatabaseReference addnewfarmerref;
        addnewfarmerref = FirebaseDatabase.getInstance().getReference();

        addnewfarmerref.addListenerForSingleValueEvent(new ValueEventListener()
        {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot)
            {
if (!(dataSnapshot.child("Farmers").child(addnewfarmerid).exists()))

{
    HashMap<String, Object> farmerdatamap = new HashMap<>();
    farmerdatamap.put("farmerid",addnewfarmerid);
    farmerdatamap.put("farmername",addnewfarmername);
    farmerdatamap.put("farmerphonenumber",addnewfarmerphoneno);


    addnewfarmerref.child("Farmers").child(addnewfarmerid).updateChildren(farmerdatamap)
            .addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()) {
                        Toast.makeText(getContext(), "Farmer added successfully", Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        Toast.makeText(getContext(), "Farmer has not been added kindly check your network ", Toast.LENGTH_SHORT).show();
                    }

                }
            });


}
else
{
    Toast.makeText(getContext(), "The farmer with this" +addnewfarmerid+ "ID number already exist", Toast.LENGTH_LONG).show();


}
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError)
            {

            }
        });

    }

}
